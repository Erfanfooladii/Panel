let btd=document.getElementById('btd');
let btl=document.getElementById('btl');
let  asid=document.getElementById('aside');

btl.addEventListener('click',function(e){
    e.preventDefault();
    asid.style.width= "250px";
    btd.style.left= "-33px";
    asid.style.transition= "0.5s";
})
btd.addEventListener('click',function(e){
    e.preventDefault();
    asid.style.width= "0%";
    btd.style.left= "0px";
    asid.style.transition= "0.5s";
})