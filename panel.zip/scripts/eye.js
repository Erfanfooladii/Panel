let hesh1=document.getElementById('hesh1');
let span1=document.getElementsByTagName('span')[0];
let span2=document.getElementsByTagName('span')[1];

hesh1.addEventListener('click',function(e){
    e.preventDefault();
    span1.style.color= '#fff';
})