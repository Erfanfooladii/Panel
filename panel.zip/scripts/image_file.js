let fil=document.getElementById('fil');
let btfi=document.getElementById('btfi');
btfi.addEventListener('click',function(e){
    e.preventDefault();
    fil.click();
},false)