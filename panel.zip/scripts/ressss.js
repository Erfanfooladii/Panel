
let tab=document.getElementsByClassName('tab');
let box=document.getElementsByClassName('box');
let hob=document.getElementsByClassName('hob');
let t=0;
function nex(){
    for(let i=0; i<box.length;i++){
        box[i].style.display= 'none';
    }
}

function cols(){
    for(let h=0; h<hob.length;h++){
        hob[h].style.display= 'none';
    }
}


tab[0].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    hob[0].style.display= 'block';
    box[0].style.display= 'block';
})
tab[1].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    hob[1].style.display= 'block';
    box[1].style.display= 'block';
})
tab[2].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    
    hob[2].style.display= 'block';
    box[2].style.display= 'block';
})
tab[3].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    hob[3].style.display= 'block';
    box[3].style.display= 'block';
})
tab[4].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    hob[4].style.display= 'block';
    box[4].style.display= 'block';
})
tab[5].addEventListener('click',function(e){
    e.preventDefault();
    cols();
    hob[5].style.display= 'block';
    window.location.assign('https://www.applern.ir')
})