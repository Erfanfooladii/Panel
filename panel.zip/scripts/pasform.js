let btnf=document.getElementById('btnf');
let frm=document.getElementById('frm2');
btnf.addEventListener('click',function(){
    frm.style.height= '268px';
    frm.style.transition= '1.2s'
})