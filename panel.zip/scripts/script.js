let tab=document.getElementsByClassName('tab');
let box=document.getElementsByClassName('box');
let hob=document.getElementsByClassName('hob');
let taab=document.getElementsByClassName('tlab');
let holb=document.getElementsByClassName('h0ob');

let t=0;
function nex(){
    for(let i=0; i<box.length;i++){
        box[i].style.display= 'none';
    }
}

function cols(){
    for(let h=0; h<hob.length;h++){
        hob[h].style.display= 'none';
    }
}

function nexs(){
    for(let i=0; i<box.length;i++){
        box[i].style.display= 'none';
    }
}

function colss(){
    for(let h=0; h<hob.length;h++){
        holb[h].style.display= 'none';
    }
}

tab[0].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[0].style.display= 'block';
    hob[0].style.display= 'block';
    box[0].style.display= 'block';
})
tab[1].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[1].style.display= 'block';
    hob[1].style.display= 'block';
    box[1].style.display= 'block';
})
tab[2].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[2].style.display= 'block';
    hob[2].style.display= 'block';
    box[2].style.display= 'block';
})
tab[3].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[3].style.display= 'block';
    hob[3].style.display= 'block';
    box[3].style.display= 'block';
})
tab[4].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[4].style.display= 'block';
    hob[4].style.display= 'block';
    box[4].style.display= 'block';
})
tab[5].addEventListener('click',function(e){
    e.preventDefault();
    cols();
    colss();
    holb[5].style.display= 'block';
    hob[5].style.display= 'block';
    window.location.assign('https://www.applern.ir')
});


taab[0].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[0].style.display= 'block';
    hob[0].style.display= 'block';
    box[0].style.display= 'block';
})
taab[1].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[1].style.display= 'block';
    hob[1].style.display= 'block';
    box[1].style.display= 'block';
})
taab[2].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[2].style.display= 'block';
    hob[2].style.display= 'block';
    box[2].style.display= 'block';
})
taab[3].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[3].style.display= 'block';
    hob[3].style.display= 'block';
    box[3].style.display= 'block';
})
taab[4].addEventListener('click',function(e){
    e.preventDefault();
    nex();
    cols();
    nexs();
    colss();
    holb[4].style.display= 'block';
    hob[4].style.display= 'block';
    box[4].style.display= 'block';
})
taab[5].addEventListener('click',function(e){
    e.preventDefault();
    cols();
    colss();
    holb[5].style.display= 'block';
    hob[5].style.display= 'block';
    window.location.assign('https://www.applern.ir')
});