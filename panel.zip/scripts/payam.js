let pm=document.getElementById('pm');
let tex=document.getElementById('mch');
let btn=document.getElementById('snd');
let pop=document.getElementById('pop');
let sho=document.getElementById('sho');
let haz=document.getElementById('haz');
let cop=document.getElementById('cop');


btn.addEventListener('click',function(){
    let ne=document.createElement('div');
    ne.innerHTML= tex.value;
    tex.value= "";
    ne.classList.toggle('pay')
    pm.appendChild(ne);
    ne.addEventListener('click',function(){
        sho.style.height= '84%';
        sho.style.transition= '0.7s';
        pop.style.display= 'flex';
        haz.addEventListener('click',function(e){
            e.preventDefault();
            pm.removeChild(ne);
            sho.style.height= '0%';
            sho.style.transition= '0.7s';
            pop.style.display= 'none';
        })
        sho.addEventListener('click',function(){
            sho.style.height= '0%';
            sho.style.transition= '0.7s';
            pop.style.display= 'none';
        })
    })
    pm.scrollBy(0,ne.scrollHeight + 100)
})
