let e=document.getElementById('pas1');
let sp1=document.getElementsByClassName('sh1');
let sp2=document.getElementsByClassName('sh2');
function paas1(){
    if(e.type === 'password'){
        e.type='text'
        
    }else{
        e.type='password'
    }
}

let f=document.getElementById('pas2');
function paas2(){
    if(f.type === 'password'){
        f.type='text'
    }else{
        f.type='password'
    }
}

let a=document.getElementById('pas3');
function paas3(){
    if(a.type === 'password'){
        a.type='text'
    }else{
        a.type='password'
    }
}